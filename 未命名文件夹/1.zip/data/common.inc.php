<?php
//数据库连接信息
$cfg_dbhost = '127.0.0.1';
$cfg_dbname = 'sq_huanyuwj';
$cfg_dbuser = 'root';
$cfg_dbpwd = 'root';
$cfg_dbprefix = 'dede_';
$cfg_db_language = 'utf8';
?>