<?php
global $allmodules;
$GLOBALS['allmodules']['0cce60bc0238aa03804682c801584991']='0cce60bc0238aa03804682c801584991.xml';
$GLOBALS['allmodules']['1f35620fb42d452fa2bdc1dee1690f92']='1f35620fb42d452fa2bdc1dee1690f92.xml';
$GLOBALS['allmodules']['572606600345b1a4bb8c810bbae434cc']='572606600345b1a4bb8c810bbae434cc.xml';
$GLOBALS['allmodules']['606c658db048ea7328ffe1c7ae2a732f']='606c658db048ea7328ffe1c7ae2a732f.xml';
$GLOBALS['allmodules']['72ffa6fabe3c236f9238a2b281bc0f93']='72ffa6fabe3c236f9238a2b281bc0f93.xml';
$GLOBALS['allmodules']['81323e93cd52ecce9f175b6aa46f5cfd']='81323e93cd52ecce9f175b6aa46f5cfd.xml';
$GLOBALS['allmodules']['acb8b88eb4a6d4bfc375c18534f9439e']='acb8b88eb4a6d4bfc375c18534f9439e.xml';
$GLOBALS['allmodules']['b437d85a7a7bc778c9c79b5ec36ab9aa']='b437d85a7a7bc778c9c79b5ec36ab9aa.xml';
$GLOBALS['allmodules']['fcd00dbb5a51d65aff6c248d221d8bcd']='fcd00dbb5a51d65aff6c248d221d8bcd.xml';
?>